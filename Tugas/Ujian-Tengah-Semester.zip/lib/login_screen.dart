import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'home_screen.dart';
import 'signup.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController userNameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  bool hidePass = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Container(
                  width: 200,
                  height: 200,
                  decoration: BoxDecoration(
                    image: DecorationImage(image: AssetImage("image/baru.png")),
                  ),
                ),
                Text(
                  "Welcome!",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 30,
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  "Login in to your existant account to Q allure",
                  style: TextStyle(
                    color: Colors.grey[700],
                    fontSize: 16,
                  ),
                ),
                SizedBox(
                  height: 50,
                ),
                TextFormField(
                  controller: userNameController,
                  style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
                  decoration: InputDecoration(prefixIcon: Icon(Icons.person), hintText: "Username or Email", border: OutlineInputBorder(borderRadius: BorderRadius.circular(30))),
                ),
                SizedBox(height: 10),
                TextFormField(
                  style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
                  obscureText: hidePass,
                  controller: passwordController,
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.lock_outlined),
                    hintText: "Password",
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
                    suffixIcon: IconButton(
                      onPressed: () {
                        print('Hide Password=$hidePass');
                        setState(() {
                          hidePass = !hidePass;
                        });
                      },
                      icon: Icon(hidePass ? Icons.visibility : Icons.visibility_off),
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fitur Dalam Pengembangan')));
                      },
                      child: Text('Forgot Password?', style: TextStyle(color: Colors.black)),
                    ),
                  ],
                ),
                SizedBox(
                  height: 30,
                ),
                SizedBox(
                  height: 50,
                  width: 200,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: Colors.blue[900],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    onPressed: () {
                      if (userNameController.text == 'user_uts' && passwordController.text == "pass_uts") {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('berhasil login'),
                          ),
                        );
                        var box = Hive.box('userBox');
                        box.put('Login', true);

                        Navigator.of(context).pushReplacement(
                          MaterialPageRoute(builder: (_) => HomeScreen()),
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Username / Password Salah")));
                      }
                    },
                    child: Text(
                      'LOG IN',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 50,
                ),
                Text(
                  "Or connect using",
                  style: TextStyle(color: Colors.grey[600]),
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fitur Dalam Pengembangan')));
                      },
                      child: Row(
                        children: [
                          Image.asset(
                            "image/facebook.png",
                            height: 25,
                          ),
                          Padding(padding: EdgeInsets.only(left: 10)),
                          Text(
                            "Facebook",
                            style: TextStyle(
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        primary: Colors.blue[800],
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fitur Dalam Pengembangan')));
                      },
                      child: Row(
                        children: [
                          Image.asset(
                            "image/google.png",
                            height: 25,
                          ),
                          Padding(padding: EdgeInsets.only(left: 10)),
                          Text(
                            "Google",
                            style: TextStyle(
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        primary: Colors.red[400],
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 50,
                ),
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Don't Have an Account?",
                          style: TextStyle(fontSize: 16),
                        ),
                        TextButton(
                            style: TextButton.styleFrom(primary: Colors.blue),
                            onPressed: () {
                              Navigator.of(context).push(MaterialPageRoute(builder: (_) => SignUpPage()));
                            },
                            child: Text(
                              'Sign Up',
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                            )),
                      ],
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
