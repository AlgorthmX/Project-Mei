import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'home_screen.dart';
import 'login_screen.dart';

class SignUpPage extends StatefulWidget {
  SignUpPage({Key? key, this.title}) : super(key: key);

  final String? title;

  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: GestureDetector(
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(builder: (_) => LoginScreen()));
            },
            child: Icon(
              Icons.arrow_back,
              color: Colors.black87,
            ),
          )),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              Padding(padding: EdgeInsets.only(top: 20)),
              Text(
                "Let's Get Started!",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.all(10),
                child: Text(
                  "Create an account to Q allure to get all features",
                  style: TextStyle(
                    color: Colors.grey[700],
                    fontSize: 16,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    TextFormField(
                      style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
                      decoration: InputDecoration(prefixIcon: Icon(Icons.person_outlined), hintText: "Full Name", border: OutlineInputBorder(borderRadius: BorderRadius.circular(30))),
                    ),
                    SizedBox(
                      height: 12,
                    ),
                    TextFormField(
                      style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
                      decoration: InputDecoration(prefixIcon: Icon(Icons.email_outlined), hintText: "Email", border: OutlineInputBorder(borderRadius: BorderRadius.circular(30))),
                    ),
                    SizedBox(
                      height: 12,
                    ),
                    TextFormField(
                      style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
                      decoration: InputDecoration(prefixIcon: Icon(Icons.phone_iphone_outlined), hintText: "Phone", border: OutlineInputBorder(borderRadius: BorderRadius.circular(30))),
                    ),
                    SizedBox(
                      height: 12,
                    ),
                    TextFormField(
                      style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
                      decoration: InputDecoration(prefixIcon: Icon(Icons.lock_outlined), hintText: "Password", border: OutlineInputBorder(borderRadius: BorderRadius.circular(30))),
                    ),
                    SizedBox(
                      height: 12,
                    ),
                    TextFormField(
                      style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
                      decoration: InputDecoration(prefixIcon: Icon(Icons.lock_outlined), hintText: "Confirm Password", border: OutlineInputBorder(borderRadius: BorderRadius.circular(30))),
                    ),
                    SizedBox(
                      height: 45,
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        primary: Colors.blue[800],
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                      ),
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fitur Dalam Pengembangan')));
                      },
                      child: Text(
                        'CREATE',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 60,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Already have an account?",
                          style: TextStyle(
                            fontSize: 16,
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).push(MaterialPageRoute(builder: (_) => LoginScreen()));
                          },
                          child: Text(
                            'Login here',
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.blue),
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
