import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Home"),
      ),
      body: Container(
          child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: GridView(
                children: [
                  Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.red,
                      ),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(
                          Icons.shopping_cart,
                          size: 50,
                          color: Colors.white,
                        ),
                        Text(
                          "Shopping",
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        )
                      ])),
                  Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.blue,
                      ),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(
                          Icons.directions_car_rounded,
                          size: 50,
                          color: Colors.white,
                        ),
                        Text(
                          "Ubers",
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        )
                      ])),
                  Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.green,
                      ),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(
                          Icons.shopping_basket,
                          size: 50,
                          color: Colors.white,
                        ),
                        Text(
                          "Groceries",
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        )
                      ])),
                  Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.grey,
                      ),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(
                          Icons.credit_card_rounded,
                          size: 50,
                          color: Colors.white,
                        ),
                        Text(
                          "Cards",
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        )
                      ])),
                  Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.blue,
                      ),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(
                          Icons.games,
                          size: 50,
                          color: Colors.white,
                        ),
                        Text(
                          "Games",
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        )
                      ])),
                  Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.red,
                      ),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(
                          Icons.fastfood_rounded,
                          size: 50,
                          color: Colors.white,
                        ),
                        Text(
                          "FastFood",
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        )
                      ])),
                ],
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10),
              ))),
    );
  }
}
