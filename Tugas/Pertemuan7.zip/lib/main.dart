import 'package:flutter/material.dart';
import 'HomePage.dart';
import 'FavoritePage.dart';
import 'FeedbackPage.dart';
import 'MorePage.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        // Application name
        home: MyBottomNavigationBar());
  }
}

class MyBottomNavigationBar extends StatefulWidget {
  const MyBottomNavigationBar({Key? key}) : super(key: key);
  _MyBottomNavigationBarState createState() => _MyBottomNavigationBarState();
}

class _MyBottomNavigationBarState extends State<MyBottomNavigationBar> {
  int _currentIndex = 0;
  final List<Widget> _children = [
    HomePage(),
    FavoritePage(),
    FeedbackPage(),
    MorePage(),
  ];

  void onTappedBar(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _children[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        onTap: onTappedBar,
        currentIndex: _currentIndex,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home', backgroundColor: Colors.blue),
          BottomNavigationBarItem(icon: Icon(Icons.favorite), label: 'Favorite', backgroundColor: Colors.blue),
          BottomNavigationBarItem(icon: Icon(Icons.feedback), label: 'Feedback', backgroundColor: Colors.blue),
          BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'More', backgroundColor: Colors.blue),
        ],
      ),
    );
  }
}
