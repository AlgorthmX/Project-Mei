package com.pertemuan7.myapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
